%Author: Ofir Weisse, www.ofirweisse.com, OfirWeisse@gmail.com
classdef FilterStorageNode < handle 
    
    properties
        apriorValsPrices;
        
        origValues;
        origValuesPrices;
        values;
        valuesPrices;
        
        threshold;
    end
    
    methods
        function obj = FilterStorageNode( valsPrices, threshold )
            obj.apriorValsPrices = valsPrices;
            obj.threshold        = threshold;
        end

        function SetValues( obj, values, previousPrices )
            obj.origValues       = values;
            newPrices            = obj.apriorValsPrices( values( :, end ) + 1 );
            obj.origValuesPrices = previousPrices .* newPrices;
            obj.origValuesPrices = obj.origValuesPrices / sum( obj.origValuesPrices );
            
            higestValsIDs    = obj.origValuesPrices > obj.threshold;
            obj.values       = obj.origValues( higestValsIDs, : );
            obj.valuesPrices = obj.origValuesPrices( higestValsIDs );
            obj.valuesPrices = obj.valuesPrices / sum( obj.valuesPrices );
        end
    end
end

