classdef XORMethod
   enumeration
      Algebric, LookUpTable
   end
end