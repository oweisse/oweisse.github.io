%Author: Ofir Weisse, www.ofirweisse.com, OfirWeisse@gmail.com
classdef X4Computer < handle

    properties
        x2Reorder;
    end
    
    methods
        function obj = X4Computer( x2Reorder )
            obj.x2Reorder = x2Reorder;
        end
        
        function [ dstValues ] = Compute( obj, srcValues )
            EXPECTED_HALF_SIZE = 12;
            plainIDs     = [1:2,   (1:2)  + EXPECTED_HALF_SIZE];
            keyIDs       = [3:4,   (3:4)  + EXPECTED_HALF_SIZE];
            addKeyIDs    = [5:6,   (5:6)  + EXPECTED_HALF_SIZE];
            subBytesIDs  = [7:8,   (7:8)  + EXPECTED_HALF_SIZE];
            shiftRowsIDs = [9:10,  (9:10) + EXPECTED_HALF_SIZE];
            x2IDs        = [11,    11     + EXPECTED_HALF_SIZE];
            xTIDs        = [12,    12     + EXPECTED_HALF_SIZE];
            
            
            idsReordered = [ plainIDs, keyIDs, addKeyIDs, ...
                             subBytesIDs, shiftRowsIDs, x2IDs, xTIDs ];
            reorderedSrc = srcValues(:, idsReordered );
            
            reorderByByteIdx = [ obj.x2Reorder,     ... %plains
                                 obj.x2Reorder + 4, ... %keys
                                 obj.x2Reorder + 8, ... %addKey
                                 obj.x2Reorder + 12,... %subBytes
                                 obj.x2Reorder + 16,... %shiftrows
                                 21:22,             ... %x2 vals
                                 23:24              ... %xt vals
            ];
            reorderedSrc     = reorderedSrc( :, reorderByByteIdx );
            reorderedX2Ids   = 21:22;
            
            computedValues      = bitxor( reorderedSrc( :, reorderedX2Ids(1) ),   ...
                                          reorderedSrc( :, reorderedX2Ids(2) )    ...
            );
            dstValues           = [ reorderedSrc, computedValues ];
        end
        
        function [ validCombinations ] = GetValidCombinations(  ...
                                                ~,              ...
                                                srcValues       ...  
        )
             validCombinations = combvec( srcValues{:} )'; %note '
        end
    end
    
end

