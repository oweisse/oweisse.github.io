%Author: Ofir Weisse, www.ofirweisse.com, OfirWeisse@gmail.com
%based on Matlab implementation of GaussianClassifier
classdef CustomGaussianClassifier  
    properties
        NDims
        ClassLevels
        NClasses
        Means
        Sigmas
        Priors
    end
    
    methods
        function obj = CustomGaussianClassifier(    ndims, ...
                                                    class_levels, ...
                                                    means, ...
                                                    sigmas, ...
                                                    priors )
            obj.NDims = ndims;
            obj.ClassLevels = class_levels;
            obj.NClasses = length( class_levels );
            obj.Means = means;
            obj.Sigmas = sigmas;
            obj.Priors = priors;
        end
        
        function postrior_porabilities = Postrior( obj, test )
            nTest = size( test, 1 );
            logCondPDF = NaN(nTest, obj.NClasses);
            
            debugVotes = zeros( obj.NClasses, obj.NDims );
            for class_idx = 1:obj.NClasses
                logPdf = zeros(nTest,1);
                class_params = [ obj.Means( class_idx, : ); obj.Sigmas( class_idx, : ) ];
                m1 = true( 1, obj.NDims );
                templogPdf = bsxfun(@plus, -0.5* (bsxfun(@rdivide,...
                            bsxfun(@minus,test(:,m1),class_params(1,:)),class_params(2,:))) .^2,...
                            -log(class_params(2,:))) -0.5 *log(2*pi);
                debugVotes( class_idx, : ) = templogPdf;
                logPdf = logPdf + sum(templogPdf,2);
                
                logCondPDF(:,class_idx)= logPdf;
                
            end
               
            log_condPdf =bsxfun(@plus,logCondPDF, log(obj.Priors));
            [maxll, cidx] = max(log_condPdf,[],2);
            postP = exp(bsxfun(@minus, log_condPdf, maxll));
            %density(i) is \sum_j \alpha_j P(x_i| \theta_j)/ exp(maxll(i))
            density = nansum(postP,2); %ignore the empty classes
            %normalize posteriors
            postP = bsxfun(@rdivide, postP, density);
            
            postrior_porabilities = postP;
        end
        
        function [ predictions, postriors ] = predict( obj, test )
           postrior_porabilities = obj.Postrior( test );
           
           [~, class_ids ] = max( postrior_porabilities, [], 2 );
           predictions = obj.ClassLevels( class_ids );
           
           if nargout == 2
               postriors = postrior_porabilities;
           end
        end
    end
    
end

