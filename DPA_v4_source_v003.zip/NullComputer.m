classdef NullComputer < handle

    properties
    end
    
    methods
        function obj = NullComputer(  )
        end
        
        function [ dstValues ] = Compute( ~, srcValues )
            dstValues  = [ srcValues, srcValues( :, end ) ];
        end
    end
    
end

