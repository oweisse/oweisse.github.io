%Author: Ofir Weisse, www.ofirweisse.com, OfirWeisse@gmail.com
classdef AddKeyComputer < handle
    properties
    end
    
    methods
        function obj = AddKeyComputer()
        end
        
        function [ dstValues ] = Compute( ~, srcValues )
            computedValues      = bitxor( srcValues( :, 1 ),  ...
                                          srcValues( :, 2 )   ...
            );
            dstValues           = [ srcValues, computedValues ];
        end
    end
    
end

