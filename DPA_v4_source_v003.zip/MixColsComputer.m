%Author: Ofir Weisse, www.ofirweisse.com, OfirWeisse@gmail.com
classdef MixColsComputer < handle
    properties
    end
    
    methods
        function obj = MixColsComputer(  )
        end
        
        function [ dstValues ] = Compute( ~, srcValues )
%             plainIDs     = 1:4;
%             keyIDs       = 5:8;
%             addKeyIDs    = 9:12;
%             subBytesIDs  = 13:16;
            shiftRowsIDs = 17:20;
%             x2_IDs = 21:24;
            xt_IDs = 25:28;
            x4_ID   = 29;
            
            computedMixCols = zeros( size( srcValues, 1 ), 4 );
            xor4      = srcValues( :, x4_ID );
            shiftRows = srcValues( :, shiftRowsIDs );
            xtimes    = srcValues( :, xt_IDs );
            
            for rowIdx = 1:4
                computedMixCols( :, rowIdx  ) =                             ...
                                    bitxor( xor4,                           ...
                                            bitxor( shiftRows( :, rowIdx ), ...
                                                    xtimes( :, rowIdx )     ...
                                            )                               ...
                );
            end

            dstValues  = [ srcValues, computedMixCols ];
        end
    end
end

