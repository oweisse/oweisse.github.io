%Author: Ofir Weisse, www.ofirweisse.com, OfirWeisse@gmail.com
classdef XTComputer < handle
    methods
        function obj = XTComputer()
        end
        
        function [ dstValues ] = Compute( ~, srcValues )
            computedValues = aes_xtimes( srcValues( :, end ) );
            dstValues      = [ srcValues, computedValues ];
        end
    end
    
end

