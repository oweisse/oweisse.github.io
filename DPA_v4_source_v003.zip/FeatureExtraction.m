classdef FeatureExtraction
   enumeration
      TakeWindows, TakeTopScore, PCA, OpportunisticTopScore, OpportunisticTopScore_PCA
   end
end