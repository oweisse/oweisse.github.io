%Author: Ofir Weisse, www.ofirweisse.com, OfirWeisse@gmail.com
classdef X2Computer < handle
   
    properties
        
    end
    
    methods
        function obj = X2Computer()
        end
        
        function [ dstValues ] = Compute( ~, srcValues )
            EXPECTED_HALF_SIZE = 5;
            plainIDs     = [1, 1 + EXPECTED_HALF_SIZE];
            keyIDs       = [2, 2 + EXPECTED_HALF_SIZE];
            addKeyIDs    = [3, 3 + EXPECTED_HALF_SIZE];
            subBytesIDs  = [4, 4 + EXPECTED_HALF_SIZE];
            shiftRowsIDs = [5, 5 + EXPECTED_HALF_SIZE];
            
            idsReordered = [ plainIDs, keyIDs, addKeyIDs, subBytesIDs, shiftRowsIDs];
            reorderedSrc = srcValues(:, idsReordered );
            src1ShiftRowsID = 7;
            src2ShiftRowsID = 8;
            
            computedValues      = bitxor( reorderedSrc( :, src1ShiftRowsID ),   ...
                                          reorderedSrc( :, src2ShiftRowsID )    ...
            );
            dstValues           = [ reorderedSrc, computedValues ];
        end
        
        function [ validCombinations ] = GetValidCombinations(    ...
                                                ~,                ...
                                                srcValues         ...
        )
            validCombinations = combvec( srcValues{:} )'; %note '
        end
    end
    
end

