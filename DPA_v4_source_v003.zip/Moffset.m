function [ masks ] = Moffset( offsets )
%Moffset calulate Moffset
%In:
%   offsets - vetor of offsets
%Out:
%   masks - matrix of dimensions length( offsets ) X 16
%           each row k is 16 byte values of mask with offset == offsets( k )
   
    if min( offsets ) < 0 || max( offsets ) > 15
        error( 'offset must be in range [0, 15]' );
    end

    M_str = '0x00; 0x0f; 0x36; 0x39; 0x53; 0x5c; 0x65; 0x6a; 0x95; 0x9a; 0xa3; 0xac; 0xc6; 0xc9; 0xf0; 0xff';
    M = sscanf( M_str, '0x%2x; 0x%2x; 0x%2x; 0x%2x; 0x%2x; 0x%2x; 0x%2x; 0x%2x; 0x%2x; 0x%2x; 0x%2x; 0x%2x; 0x%2x; 0x%2x; 0x%2x; 0x%2x; ' );
    M = M';
    MASK_SIZE = 16;

    masks = zeros( length( offsets ), MASK_SIZE );
    for offsetIndex = 1 : length( offsets )
        masks( offsetIndex, : ) = circshift( M, [ 0, -offsets( offsetIndex ) ] );
    end
end

