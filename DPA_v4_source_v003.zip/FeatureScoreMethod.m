classdef FeatureScoreMethod
   enumeration
      SimpleClassifierCorrectRate, ExtendedClassifierMeanRank, ExtendedClassifierMeanPostrior
   end
end