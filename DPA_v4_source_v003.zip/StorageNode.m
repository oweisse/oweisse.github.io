%Author: Ofir Weisse, www.ofirweisse.com, OfirWeisse@gmail.com
classdef StorageNode < handle  
    properties
        apriorValsPrices;
        
        values;
        valuesPrices;
    end
    
    methods
        function obj = StorageNode( valsPrices )
            obj.apriorValsPrices = valsPrices;
        end

        function SetValues( obj, values, previousPrices )
            obj.values       = values;
            
            if ~isempty(  obj.apriorValsPrices )
                newPrices        = obj.apriorValsPrices( values( :, end ) + 1 );
                obj.valuesPrices = previousPrices .* newPrices;
                obj.valuesPrices = obj.valuesPrices / sum( obj.valuesPrices );
            else
                obj.valuesPrices = previousPrices;
            end
           
        end
    end
    
end

